package dev.kingcrystal.gui;

import dev.kingcrystal.KingCrystalClient;
import dev.kingcrystal.modules.Module;
import dev.kingcrystal.modules.ModuleManager;
import dev.kingcrystal.modules.settings.*;
import dev.kingcrystal.util.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.*;

public class ClickGUI extends Screen {

    private final ModuleManager moduleManager;
    private final MinecraftClient client = MinecraftClient.getInstance();

    // Layout constants
    private static final int PANEL_X = 20;
    private static final int PANEL_Y = 20;
    private static final int CAT_W = 100;
    private static final int CAT_H = 28;
    private static final int CAT_GAP = 4;
    private static final int MODULE_H = 24;
    private static final int SETTING_H = 20;

    // State
    private Module.Category selectedCategory = Module.Category.HUD;
    private String searchQuery = "";
    private boolean searchFocused = false;
    private final Map<Module, Boolean> expandedSettings = new HashMap<>();

    // Scroll
    private int scrollOffset = 0;
    private int maxScroll = 0;

    // Dragging slider
    private SliderSetting draggingSetting = null;

    // Animation
    private float animProgress = 0f;
    private long openTime = 0;

    // Accent colors
    private int accentColor1 = 0xFF8800FF;
    private int accentColor2 = 0xFF0088FF;

    // Hovered module for settings panel
    private Module settingsModule = null;

    public ClickGUI(ModuleManager moduleManager) {
        super(Text.literal("KingCrystal"));
        this.moduleManager = moduleManager;
    }

    @Override
    protected void init() {
        openTime = System.currentTimeMillis();
        animProgress = 0f;
        scrollOffset = 0;
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        long elapsed = System.currentTimeMillis() - openTime;
        animProgress = Math.min(1f, elapsed / 200f);
        float eased = easeOutQuart(animProgress);
        int panelAlpha = (int)(0xFF * eased);

        // Dim background
        context.fill(0, 0, width, height, (int)(0x88 * eased) << 24);

        // === HEADER ===
        int headerW = width - 40;
        RenderUtil.drawRoundedRect(context, PANEL_X, PANEL_Y, headerW, 36, 8, applyAlpha(0xEE060612, panelAlpha));
        RenderUtil.drawGradientBorder(context, PANEL_X, PANEL_Y, headerW, 36, 8, 1,
                applyAlpha(accentColor1, panelAlpha), applyAlpha(accentColor2, panelAlpha));
        RenderUtil.drawText(context, "\u00a75\u00a7l\u2b21 KingCrystal \u00a78v1.0", PANEL_X + 8, PANEL_Y + 7,
                applyAlpha(0xFFCCAAFF, panelAlpha));

        int fps = client.getCurrentFps();
        String infoStr = "\u00a77FPS: \u00a7b" + fps;
        if (client.player != null && client.getNetworkHandler() != null) {
            var entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
            if (entry != null) infoStr += "  \u00a77Ping: \u00a7b" + entry.getLatency() + "ms";
        }
        infoStr += "  \u00a77MC: \u00a7b1.21.1";
        RenderUtil.drawText(context, infoStr, PANEL_X + 8, PANEL_Y + 20, applyAlpha(0xFFAAAAAA, panelAlpha));

        // === SEARCH BAR ===
        int searchY = PANEL_Y + 44;
        RenderUtil.drawRoundedRect(context, PANEL_X, searchY, 300, 20, 4, applyAlpha(0xCC0A0A14, panelAlpha));
        RenderUtil.drawGradientBorder(context, PANEL_X, searchY, 300, 20, 4, 1,
                applyAlpha(searchFocused ? 0xFF8800FF : 0x33888888, panelAlpha),
                applyAlpha(searchFocused ? 0xFF0088FF : 0x33888888, panelAlpha));
        String searchDisplay = searchQuery.isEmpty() && !searchFocused
                ? "\u00a77Search modules..." : searchQuery + (searchFocused ? "\u00a77|" : "");
        RenderUtil.drawText(context, searchDisplay, PANEL_X + 6, searchY + 6, applyAlpha(0xFFFFFFFF, panelAlpha));

        // === CATEGORY TABS ===
        int catY = PANEL_Y + 72;
        Module.Category[] cats = Module.Category.values();
        for (int i = 0; i < cats.length; i++) {
            Module.Category cat = cats[i];
            int cx = PANEL_X + i * (CAT_W + CAT_GAP);
            boolean sel = cat == selectedCategory && searchQuery.isEmpty();
            boolean hov = mouseX >= cx && mouseX < cx + CAT_W && mouseY >= catY && mouseY < catY + CAT_H;
            int bgCol = sel ? applyAlpha(0xCC3D0066, panelAlpha)
                    : hov ? applyAlpha(0x661A0033, panelAlpha)
                    : applyAlpha(0xCC0A0A14, panelAlpha);
            RenderUtil.drawRoundedRect(context, cx, catY, CAT_W, CAT_H, 5, bgCol);
            if (sel || hov) {
                RenderUtil.drawGradientBorder(context, cx, catY, CAT_W, CAT_H, 5, 1,
                        applyAlpha(accentColor1, panelAlpha), applyAlpha(accentColor2, panelAlpha));
            }
            RenderUtil.drawTextCentered(context, (sel ? "\u00a7b" : "\u00a77") + cat.getDisplayName(),
                    cx + CAT_W / 2, catY + 10, applyAlpha(0xFFFFFFFF, panelAlpha));
        }

        // === MODULE LIST ===
        int modListX = PANEL_X;
        int modListY = catY + CAT_H + 8;
        int modListW = 220;
        int modListH = height - modListY - 20;

        RenderUtil.drawRoundedRect(context, modListX, modListY, modListW, modListH, 6, applyAlpha(0xEE060612, panelAlpha));
        RenderUtil.drawGradientBorder(context, modListX, modListY, modListW, modListH, 6, 1,
                applyAlpha(accentColor1, 100), applyAlpha(accentColor2, 100));

        List<Module> visibleModules = searchQuery.isEmpty()
                ? moduleManager.getModulesByCategory(selectedCategory)
                : moduleManager.search(searchQuery);

        context.enableScissor(modListX + 2, modListY + 2, modListX + modListW - 2, modListY + modListH - 2);

        int drawY = modListY + 4 - scrollOffset;
        int totalH = 0;
        settingsModule = null;

        for (Module module : visibleModules) {
            boolean hov = mouseX >= modListX + 2 && mouseX < modListX + modListW - 2
                    && mouseY >= drawY && mouseY < drawY + MODULE_H;
            boolean expanded = expandedSettings.getOrDefault(module, false);

            int rowBg = module.isEnabled()
                    ? applyAlpha(0xCC2D004D, panelAlpha)
                    : hov ? applyAlpha(0x661A0033, panelAlpha)
                    : applyAlpha(0x220A0A14, panelAlpha);
            RenderUtil.drawRoundedRect(context, modListX + 2, drawY, modListW - 4, MODULE_H - 2, 4, rowBg);

            if (module.isEnabled()) {
                RenderUtil.drawGradientBorder(context, modListX + 2, drawY, modListW - 4, MODULE_H - 2, 4, 1,
                        applyAlpha(accentColor1, panelAlpha), applyAlpha(accentColor2, panelAlpha));
            }

            String modName = (module.isEnabled() ? "\u00a7b" : "\u00a77") + module.getName();
            RenderUtil.drawText(context, modName, modListX + 8, drawY + 7, applyAlpha(0xFFFFFFFF, panelAlpha));

            if (!module.getSettings().isEmpty()) {
                String arrow = expanded ? "\u00a77\u25be" : "\u00a77\u25b8";
                RenderUtil.drawText(context, arrow, modListX + modListW - 14, drawY + 7,
                        applyAlpha(0xFF888888, panelAlpha));
            }

            if (hov) settingsModule = module;

            drawY += MODULE_H;
            totalH += MODULE_H;

            if (expanded) {
                for (Setting<?> setting : module.getSettings()) {
                    int settY = drawY;
                    drawSetting(context, setting, modListX + 4, settY, modListW - 8, mouseX, mouseY, panelAlpha);
                    drawY += SETTING_H + 2;
                    totalH += SETTING_H + 2;
                }
            }
        }

        maxScroll = Math.max(0, totalH - modListH + 8);
        context.disableScissor();

        // === SETTINGS PANEL ===
        if (settingsModule != null && !settingsModule.getSettings().isEmpty()) {
            int spX = modListX + modListW + 8;
            int spY = modListY;
            int spW = 180;
            int spH = settingsModule.getSettings().size() * (SETTING_H + 4) + 40;

            RenderUtil.drawRoundedRect(context, spX, spY, spW, spH, 6, applyAlpha(0xEE060612, panelAlpha));
            RenderUtil.drawGradientBorder(context, spX, spY, spW, spH, 6, 1,
                    applyAlpha(accentColor1, 100), applyAlpha(accentColor2, 100));
            RenderUtil.drawText(context, "\u00a7b" + settingsModule.getName(), spX + 6, spY + 6,
                    applyAlpha(0xFFCCAAFF, panelAlpha));
            RenderUtil.drawLine(context, spX + 4, spY + 17, spX + spW - 4, spY + 17,
                    applyAlpha(0x558800FF, panelAlpha));

            int sy = spY + 22;
            for (Setting<?> setting : settingsModule.getSettings()) {
                drawSetting(context, setting, spX + 4, sy, spW - 8, mouseX, mouseY, panelAlpha);
                sy += SETTING_H + 4;
            }
        }

        RenderUtil.drawText(context, "\u00a78[C] Color  [ESC] Close", PANEL_X, height - 14,
                applyAlpha(0xFF555577, panelAlpha));

        super.render(context, mouseX, mouseY, delta);
    }

    private void drawSetting(DrawContext ctx, Setting<?> setting, int x, int y, int w,
                              int mouseX, int mouseY, int alpha) {
        if (setting instanceof BooleanSetting s) {
            RenderUtil.drawRoundedRect(ctx, x, y, w, SETTING_H - 1, 3, applyAlpha(0x33222222, alpha));
            RenderUtil.drawText(ctx, "\u00a77" + s.getName(), x + 4, y + 5, applyAlpha(0xFFBBBBBB, alpha));
            int toggleX = x + w - 26;
            int toggleColor = s.getValue() ? applyAlpha(accentColor1, alpha) : applyAlpha(0xFF444444, alpha);
            RenderUtil.drawRoundedRect(ctx, toggleX, y + 4, 22, 11, 5, toggleColor);
            int knobX = s.getValue() ? toggleX + 12 : toggleX + 1;
            RenderUtil.drawRoundedRect(ctx, knobX, y + 5, 9, 9, 4, applyAlpha(0xFFFFFFFF, alpha));

        } else if (setting instanceof SliderSetting s) {
            RenderUtil.drawRoundedRect(ctx, x, y, w, SETTING_H - 1, 3, applyAlpha(0x33222222, alpha));
            RenderUtil.drawText(ctx, "\u00a77" + s.getName() + ": \u00a7b" + String.format("%.1f", s.getValue()),
                    x + 4, y + 5, applyAlpha(0xFFBBBBBB, alpha));
            int barX = x + 4, barY = y + 14, barW = w - 8, barH = 3;
            RenderUtil.drawRoundedRect(ctx, barX, barY, barW, barH, 1, applyAlpha(0xFF222222, alpha));
            int filled = (int)(barW * s.getPercent());
            if (filled > 0) {
                RenderUtil.drawRoundedRect(ctx, barX, barY, filled, barH, 1, applyAlpha(accentColor1, alpha));
            }
            RenderUtil.drawCircle(ctx, barX + filled, barY + 1, 4, applyAlpha(0xFFFFFFFF, alpha));

        } else if (setting instanceof ModeSetting s) {
            RenderUtil.drawRoundedRect(ctx, x, y, w, SETTING_H - 1, 3, applyAlpha(0x33222222, alpha));
            RenderUtil.drawText(ctx, "\u00a77" + s.getName(), x + 4, y + 5, applyAlpha(0xFFBBBBBB, alpha));
            int valW = client.textRenderer.getWidth(s.getValue()) + 8;
            int valX = x + w - valW - 2;
            RenderUtil.drawRoundedRect(ctx, valX, y + 3, valW, 13, 3, applyAlpha(0x44440088, alpha));
            RenderUtil.drawText(ctx, "\u00a7b" + s.getValue(), valX + 3, y + 5, applyAlpha(0xFFCCAAFF, alpha));

        } else if (setting instanceof ColorSetting s) {
            RenderUtil.drawRoundedRect(ctx, x, y, w, SETTING_H - 1, 3, applyAlpha(0x33222222, alpha));
            RenderUtil.drawText(ctx, "\u00a77" + s.getName(), x + 4, y + 5, applyAlpha(0xFFBBBBBB, alpha));
            RenderUtil.drawRoundedRect(ctx, x + w - 18, y + 3, 14, 13, 3, s.getValue());
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int mx = (int) mouseX, my = (int) mouseY;
        int catY = PANEL_Y + 72;

        // Search bar
        int searchY = PANEL_Y + 44;
        if (mx >= PANEL_X && mx < PANEL_X + 300 && my >= searchY && my < searchY + 20) {
            searchFocused = true;
            return true;
        } else {
            searchFocused = false;
        }

        // Category tabs
        Module.Category[] cats = Module.Category.values();
        for (int i = 0; i < cats.length; i++) {
            int cx = PANEL_X + i * (CAT_W + CAT_GAP);
            if (mx >= cx && mx < cx + CAT_W && my >= catY && my < catY + CAT_H) {
                selectedCategory = cats[i];
                searchQuery = "";
                scrollOffset = 0;
                return true;
            }
        }

        // Module list
        int modListX = PANEL_X;
        int modListY = catY + CAT_H + 8;
        int modListW = 220;
        int modListH = height - modListY - 20;

        if (mx >= modListX && mx < modListX + modListW && my >= modListY && my < modListY + modListH) {
            List<Module> visibleModules = searchQuery.isEmpty()
                    ? moduleManager.getModulesByCategory(selectedCategory)
                    : moduleManager.search(searchQuery);

            int drawY = modListY + 4 - scrollOffset;
            for (Module module : visibleModules) {
                if (my >= drawY && my < drawY + MODULE_H) {
                    if (button == 0) {
                        module.toggle();
                    } else if (button == 1) {
                        boolean cur = expandedSettings.getOrDefault(module, false);
                        expandedSettings.put(module, !cur);
                    }
                    return true;
                }
                drawY += MODULE_H;
                if (expandedSettings.getOrDefault(module, false)) {
                    for (Setting<?> setting : module.getSettings()) {
                        if (my >= drawY && my < drawY + SETTING_H + 2) {
                            handleSettingClick(setting, mx, my, drawY, modListX + 4, modListW - 8, button);
                            return true;
                        }
                        drawY += SETTING_H + 2;
                    }
                }
            }
        }

        // Settings panel
        if (settingsModule != null) {
            int spX = modListX + modListW + 8;
            int spY = modListY;
            int spW = 180;
            int sy = spY + 22;
            for (Setting<?> setting : settingsModule.getSettings()) {
                if (my >= sy && my < sy + SETTING_H + 4) {
                    handleSettingClick(setting, mx, my, sy, spX + 4, spW - 8, button);
                    return true;
                }
                sy += SETTING_H + 4;
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void handleSettingClick(Setting<?> setting, int mx, int my, int drawY,
                                     int x, int w, int button) {
        if (setting instanceof BooleanSetting s) {
            int toggleX = x + w - 26;
            if (mx >= toggleX && mx < toggleX + 22) s.toggle();
        } else if (setting instanceof ModeSetting s) {
            s.cycle();
        } else if (setting instanceof SliderSetting s) {
            int barX = x + 4, barW = w - 8;
            int barY = drawY + 14;
            if (my >= barY - 4 && my <= barY + 8) {
                draggingSetting = s;
                s.setPercent((double)(mx - barX) / barW);
            }
        }
        KingCrystalClient.getInstance().getConfigManager()
                .save(KingCrystalClient.getInstance().getModuleManager());
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingSetting != null) {
            int modListX = PANEL_X;
            int catY = PANEL_Y + 72;
            int modListY = catY + CAT_H + 8;
            int modListW = 220;
            int barX = modListX + 4 + 4;
            int barW = modListW - 16;
            draggingSetting.setPercent(Math.max(0, Math.min(1, (mouseX - barX) / barW)));
            KingCrystalClient.getInstance().getConfigManager()
                    .save(KingCrystalClient.getInstance().getModuleManager());
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        draggingSetting = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollOffset = Math.max(0, Math.min(maxScroll, scrollOffset - (int)(verticalAmount * 15)));
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        if (searchFocused) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !searchQuery.isEmpty()) {
                searchQuery = searchQuery.substring(0, searchQuery.length() - 1);
                scrollOffset = 0;
                return true;
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchFocused) {
            searchQuery += chr;
            scrollOffset = 0;
            return true;
        }
        if (chr == 'c' || chr == 'C') {
            cycleAccentColors();
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    private void cycleAccentColors() {
        int[][] themes = {
            {0xFF8800FF, 0xFF0088FF},
            {0xFF00FFCC, 0xFF0044FF},
            {0xFFFF0066, 0xFFFF8800},
            {0xFF00FF44, 0xFF00CCFF},
        };
        int currentTheme = 0;
        for (int i = 0; i < themes.length; i++) {
            if (themes[i][0] == accentColor1) { currentTheme = i; break; }
        }
        int next = (currentTheme + 1) % themes.length;
        accentColor1 = themes[next][0];
        accentColor2 = themes[next][1];
    }

    private static int applyAlpha(int color, int alpha) {
        int baseAlpha = (color >> 24) & 0xFF;
        int newAlpha = (int)(baseAlpha * (alpha / 255f));
        return (newAlpha << 24) | (color & 0x00FFFFFF);
    }

    private static float easeOutQuart(float t) {
        return 1f - (float) Math.pow(1 - t, 4);
    }
}
