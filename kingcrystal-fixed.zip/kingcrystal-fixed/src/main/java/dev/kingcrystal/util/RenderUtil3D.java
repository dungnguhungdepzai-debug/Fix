package dev.kingcrystal.util;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;

public class RenderUtil3D {

    public static void drawBoxOutline(MatrixStack matrices, double x1, double y1, double z1,
                                       double x2, double y2, double z2, int color, float lineWidth) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.lineWidth(lineWidth);
        RenderSystem.disableDepthTest();

        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;
        float a = ((color >> 24) & 0xFF) / 255f;

        // Bottom face
        addLine(buffer, matrix, x1, y1, z1, x2, y1, z1, r, g, b, a);
        addLine(buffer, matrix, x2, y1, z1, x2, y1, z2, r, g, b, a);
        addLine(buffer, matrix, x2, y1, z2, x1, y1, z2, r, g, b, a);
        addLine(buffer, matrix, x1, y1, z2, x1, y1, z1, r, g, b, a);
        // Top face
        addLine(buffer, matrix, x1, y2, z1, x2, y2, z1, r, g, b, a);
        addLine(buffer, matrix, x2, y2, z1, x2, y2, z2, r, g, b, a);
        addLine(buffer, matrix, x2, y2, z2, x1, y2, z2, r, g, b, a);
        addLine(buffer, matrix, x1, y2, z2, x1, y2, z1, r, g, b, a);
        // Verticals
        addLine(buffer, matrix, x1, y1, z1, x1, y2, z1, r, g, b, a);
        addLine(buffer, matrix, x2, y1, z1, x2, y2, z1, r, g, b, a);
        addLine(buffer, matrix, x2, y1, z2, x2, y2, z2, r, g, b, a);
        addLine(buffer, matrix, x1, y1, z2, x1, y2, z2, r, g, b, a);

        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.enableDepthTest();
        RenderSystem.lineWidth(1.0f);
    }

    private static void addLine(BufferBuilder buf, Matrix4f mat,
                                 double x1, double y1, double z1,
                                 double x2, double y2, double z2,
                                 float r, float g, float b, float a) {
        buf.vertex(mat, (float)x1, (float)y1, (float)z1).color(r, g, b, a);
        buf.vertex(mat, (float)x2, (float)y2, (float)z2).color(r, g, b, a);
    }

    public static void drawTracer(MatrixStack matrices, double x, double y, double z, int color) {
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.lineWidth(1.5f);
        RenderSystem.disableDepthTest();

        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;
        float a = ((color >> 24) & 0xFF) / 255f;

        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        buffer.vertex(matrix, 0f, 0f, 0f).color(r, g, b, a);
        buffer.vertex(matrix, (float)x, (float)y, (float)z).color(r, g, b, a);

        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.enableDepthTest();
        RenderSystem.lineWidth(1.0f);
    }
}
