package dev.kingcrystal.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;

public class RenderUtil {

    public static void drawRect(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + h, color);
    }

    public static void drawRoundedRect(DrawContext ctx, int x, int y, int w, int h, int radius, int color) {
        // Simplified rounded rect using multiple fills
        int r = Math.min(radius, Math.min(w / 2, h / 2));
        // Center + horizontal + vertical strips
        ctx.fill(x + r, y, x + w - r, y + h, color);
        ctx.fill(x, y + r, x + r, y + h - r, color);
        ctx.fill(x + w - r, y + r, x + w, y + h - r, color);
        // Corners (simple filled arcs)
        for (int i = 0; i <= r; i++) {
            int len = (int) Math.sqrt(r * r - (r - i) * (r - i));
            // Top-left
            ctx.fill(x + r - len, y + i, x + r, y + i + 1, color);
            // Top-right
            ctx.fill(x + w - r, y + i, x + w - r + len, y + i + 1, color);
            // Bottom-left
            ctx.fill(x + r - len, y + h - i - 1, x + r, y + h - i, color);
            // Bottom-right
            ctx.fill(x + w - r, y + h - i - 1, x + w - r + len, y + h - i, color);
        }
    }

    public static void drawGradientBorder(DrawContext ctx, int x, int y, int w, int h, int radius, int thickness, int color1, int color2) {
        // Top
        ctx.fillGradient(x, y, x + w, y + thickness, color1, color2);
        // Bottom
        ctx.fillGradient(x, y + h - thickness, x + w, y + h, color2, color1);
        // Left
        ctx.fillGradient(x, y, x + thickness, y + h, color1, color2);
        // Right
        ctx.fillGradient(x + w - thickness, y, x + w, y + h, color1, color2);
    }

    public static void drawLine(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        ctx.fill(x1, y1, x2, y2 + 1, color);
    }

    public static void drawText(DrawContext ctx, String text, int x, int y, int color) {
        ctx.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, text, x, y, color);
    }

    public static void drawTextCentered(DrawContext ctx, String text, int cx, int y, int color) {
        int w = MinecraftClient.getInstance().textRenderer.getWidth(text);
        ctx.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, text, cx - w / 2, y, color);
    }

    public static void drawCircle(DrawContext ctx, int cx, int cy, int radius, int color) {
        for (int y = -radius; y <= radius; y++) {
            for (int x = -radius; x <= radius; x++) {
                if (x * x + y * y <= radius * radius) {
                    ctx.fill(cx + x, cy + y, cx + x + 1, cy + y + 1, color);
                }
            }
        }
    }

    public static void drawCircleOutline(DrawContext ctx, int cx, int cy, int radius, int thickness, int color) {
        for (int t = 0; t < thickness; t++) {
            int r = radius - t;
            for (double angle = 0; angle < Math.PI * 2; angle += 0.05) {
                int x = (int)(cx + r * Math.cos(angle));
                int y = (int)(cy + r * Math.sin(angle));
                ctx.fill(x, y, x + 1, y + 1, color);
            }
        }
    }

    public static int withAlpha(int color, int alpha) {
        return (alpha << 24) | (color & 0x00FFFFFF);
    }

    public static int lerpColor(int c1, int c2, float t) {
        int a1 = (c1 >> 24) & 0xFF, r1 = (c1 >> 16) & 0xFF, g1 = (c1 >> 8) & 0xFF, b1 = c1 & 0xFF;
        int a2 = (c2 >> 24) & 0xFF, r2 = (c2 >> 16) & 0xFF, g2 = (c2 >> 8) & 0xFF, b2 = c2 & 0xFF;
        return ((int)(a1 + (a2 - a1) * t) << 24) |
               ((int)(r1 + (r2 - r1) * t) << 16) |
               ((int)(g1 + (g2 - g1) * t) << 8)  |
                (int)(b1 + (b2 - b1) * t);
    }
}
