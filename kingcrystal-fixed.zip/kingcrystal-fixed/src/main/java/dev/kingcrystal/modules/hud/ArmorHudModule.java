package dev.kingcrystal.modules.hud;

import dev.kingcrystal.event.EventHandler;
import dev.kingcrystal.event.events.RenderHudEvent;
import dev.kingcrystal.modules.Module;
import dev.kingcrystal.modules.settings.ModeSetting;
import dev.kingcrystal.modules.settings.SliderSetting;
import dev.kingcrystal.util.RenderUtil;
import net.minecraft.item.ItemStack;

public class ArmorHudModule extends Module {

    private final SliderSetting x = addSetting(new SliderSetting("X", "HUD X", 10, 0, 1920, 1));
    private final SliderSetting y = addSetting(new SliderSetting("Y", "HUD Y", 300, 0, 1080, 1));
    private final ModeSetting mode = addSetting(new ModeSetting("Mode", "Display mode", "Horizontal", "Horizontal", "Vertical"));

    public ArmorHudModule() {
        super("Armor HUD", "Shows armor durability and items", Category.HUD);
    }

    @EventHandler
    public void onRenderHud(RenderHudEvent event) {
        if (mc.player == null) return;

        int px = (int) x.getValue();
        int py = (int) y.getValue();
        boolean vertical = mode.getValue().equals("Vertical");

        // Armor slots: head=3, chest=2, legs=1, feet=0
        for (int slot = 3; slot >= 0; slot--) {
            ItemStack stack = mc.player.getInventory().getArmorStack(slot);
            if (stack.isEmpty()) continue;

            int idx = 3 - slot;
            int drawX = vertical ? px : px + idx * 20;
            int drawY = vertical ? py + idx * 20 : py;

            event.getContext().drawItem(stack, drawX, drawY);

            if (stack.isDamageable()) {
                int durability = stack.getMaxDamage() - stack.getDamage();
                float durPct = (float) durability / stack.getMaxDamage();
                int barColor = durPct > 0.5f ? 0xFF44FF44 : durPct > 0.25f ? 0xFFFFAA00 : 0xFFFF3333;

                int barX = drawX, barY = drawY + 17;
                RenderUtil.drawRect(event.getContext(), barX, barY, 16, 2, 0xFF222222);
                RenderUtil.drawRect(event.getContext(), barX, barY, (int)(16 * durPct), 2, barColor);
            }
        }
    }
}
