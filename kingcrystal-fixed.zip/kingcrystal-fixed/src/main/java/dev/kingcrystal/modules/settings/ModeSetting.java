package dev.kingcrystal.modules.settings;

import java.util.Arrays;
import java.util.List;

public class ModeSetting extends Setting<String> {
    private final List<String> options;

    public ModeSetting(String name, String description, String defaultValue, String... options) {
        super(name, description, defaultValue);
        this.options = Arrays.asList(options);
        if (!this.options.contains(defaultValue)) {
            throw new IllegalArgumentException("Default value must be one of the options");
        }
    }

    public List<String> getOptions() { return options; }

    public void cycle() {
        int idx = options.indexOf(value);
        value = options.get((idx + 1) % options.size());
    }

    @Override
    public void setValue(String value) {
        if (options.contains(value)) this.value = value;
    }
}
