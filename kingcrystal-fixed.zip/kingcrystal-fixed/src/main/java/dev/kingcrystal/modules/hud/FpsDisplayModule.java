package dev.kingcrystal.modules.hud;

import dev.kingcrystal.event.EventHandler;
import dev.kingcrystal.event.events.RenderHudEvent;
import dev.kingcrystal.modules.Module;
import dev.kingcrystal.modules.settings.SliderSetting;
import dev.kingcrystal.util.RenderUtil;

public class FpsDisplayModule extends Module {

    private final SliderSetting x = addSetting(new SliderSetting("X", "HUD X", 10, 0, 1920, 1));
    private final SliderSetting y = addSetting(new SliderSetting("Y", "HUD Y", 90, 0, 1080, 1));

    public FpsDisplayModule() {
        super("FPS Display", "Shows current frames per second", Category.HUD);
    }

    @EventHandler
    public void onRenderHud(RenderHudEvent event) {
        int fps = mc.getCurrentFps();
        int px = (int) x.getValue();
        int py = (int) y.getValue();

        int color = fps >= 100 ? 0xFF44FF44 : fps >= 60 ? 0xFFFFAA00 : 0xFFFF3333;

        RenderUtil.drawRoundedRect(event.getContext(), px - 2, py - 2, 100, 20, 4, 0xCC0A0A14);
        RenderUtil.drawText(event.getContext(), "§5§lFPS §r" + fps, px, py, color);
    }
}
