package dev.kingcrystal.modules.hud;

import dev.kingcrystal.event.EventHandler;
import dev.kingcrystal.event.events.RenderHudEvent;
import dev.kingcrystal.modules.Module;
import dev.kingcrystal.modules.settings.SliderSetting;
import dev.kingcrystal.util.RenderUtil;
import net.minecraft.client.network.PlayerListEntry;

public class PingDisplayModule extends Module {

    private final SliderSetting x = addSetting(new SliderSetting("X", "HUD X", 10, 0, 1920, 1));
    private final SliderSetting y = addSetting(new SliderSetting("Y", "HUD Y", 110, 0, 1080, 1));

    public PingDisplayModule() {
        super("Ping Display", "Shows current server ping", Category.HUD);
    }

    @EventHandler
    public void onRenderHud(RenderHudEvent event) {
        if (mc.player == null || mc.getNetworkHandler() == null) return;

        PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        int ping = entry != null ? entry.getLatency() : -1;

        int px = (int) x.getValue();
        int py = (int) y.getValue();

        int color = ping < 0 ? 0xFF888888 : ping < 80 ? 0xFF44FF44 : ping < 150 ? 0xFFFFAA00 : 0xFFFF3333;
        String text = ping < 0 ? "N/A" : ping + "ms";

        RenderUtil.drawRoundedRect(event.getContext(), px - 2, py - 2, 100, 20, 4, 0xCC0A0A14);
        RenderUtil.drawText(event.getContext(), "§5§lPing §r" + text, px, py, color);
    }
}
