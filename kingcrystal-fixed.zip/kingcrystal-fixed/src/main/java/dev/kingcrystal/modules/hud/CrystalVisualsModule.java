package dev.kingcrystal.modules.hud;

import dev.kingcrystal.event.EventHandler;
import dev.kingcrystal.event.events.RenderWorldEvent;
import dev.kingcrystal.modules.Module;
import dev.kingcrystal.modules.settings.BooleanSetting;
import dev.kingcrystal.modules.settings.ColorSetting;
import dev.kingcrystal.modules.settings.SliderSetting;
import dev.kingcrystal.util.RenderUtil3D;
import net.minecraft.entity.decoration.EndCrystalEntity;

import java.util.List;

public class CrystalVisualsModule extends Module {

    private final BooleanSetting esp = addSetting(new BooleanSetting("ESP Box", "Draw box around crystals", true));
    private final BooleanSetting tracers = addSetting(new BooleanSetting("Tracers", "Draw lines to crystals", false));
    private final SliderSetting range = addSetting(new SliderSetting("Range", "Render range", 20, 1, 50, 1));
    private final ColorSetting espColor = addSetting(new ColorSetting("ESP Color", "Box color", 0x888800FF));
    private final ColorSetting tracerColor = addSetting(new ColorSetting("Tracer Color", "Tracer color", 0x8800CCFF));

    public CrystalVisualsModule() {
        super("Crystal Visuals", "Visual effects for End Crystals", Category.VISUAL);
    }

    @EventHandler
    public void onRenderWorld(RenderWorldEvent event) {
        if (mc.world == null || mc.player == null) return;

        List<EndCrystalEntity> crystals = mc.world.getEntitiesByClass(
                EndCrystalEntity.class,
                mc.player.getBoundingBox().expand(range.getValue()),
                e -> true
        );

        for (EndCrystalEntity crystal : crystals) {
            double x = crystal.lastRenderX - event.getCamera().getPos().x;
            double y = crystal.lastRenderY - event.getCamera().getPos().y;
            double z = crystal.lastRenderZ - event.getCamera().getPos().z;

            if (esp.getValue()) {
                RenderUtil3D.drawBoxOutline(event.getMatrixStack(),
                        x - 0.5, y - 0.5, z - 0.5,
                        x + 0.5, y + 1.5, z + 0.5,
                        espColor.getValue(), 2f);
            }

            if (tracers.getValue()) {
                RenderUtil3D.drawTracer(event.getMatrixStack(),
                        x, y + 0.5, z,
                        tracerColor.getValue());
            }
        }
    }
}
