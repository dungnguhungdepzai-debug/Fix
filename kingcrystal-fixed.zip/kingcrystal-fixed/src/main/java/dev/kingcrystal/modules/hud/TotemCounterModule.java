package dev.kingcrystal.modules.hud;

import dev.kingcrystal.event.EventHandler;
import dev.kingcrystal.event.events.RenderHudEvent;
import dev.kingcrystal.modules.Module;
import dev.kingcrystal.modules.settings.SliderSetting;
import dev.kingcrystal.util.RenderUtil;
import net.minecraft.item.Items;

public class TotemCounterModule extends Module {

    private final SliderSetting x = addSetting(new SliderSetting("X", "HUD X", 10, 0, 1920, 1));
    private final SliderSetting y = addSetting(new SliderSetting("Y", "HUD Y", 50, 0, 1080, 1));

    private int lastCount = 0;
    private long popTime = 0;

    public TotemCounterModule() {
        super("Totem Counter", "Counts totems and shows pop notifications", Category.HUD);
    }

    @EventHandler
    public void onRenderHud(RenderHudEvent event) {
        if (mc.player == null) return;

        int count = 0;
        for (int i = 0; i < mc.player.getInventory().size(); i++) {
            var stack = mc.player.getInventory().getStack(i);
            if (stack.getItem() == Items.TOTEM_OF_UNDYING) count += stack.getCount();
        }
        // Check offhand
        var off = mc.player.getOffHandStack();
        if (off.getItem() == Items.TOTEM_OF_UNDYING) count += off.getCount();

        if (count < lastCount) popTime = System.currentTimeMillis();
        lastCount = count;

        int px = (int) x.getValue();
        int py = (int) y.getValue();

        RenderUtil.drawRoundedRect(event.getContext(), px - 2, py - 2, 130, 20, 4, 0xCC0A0A14);

        int color = count <= 1 ? 0xFFFF3333 : count <= 3 ? 0xFFFFAA00 : 0xFF44FF44;
        RenderUtil.drawText(event.getContext(), "§5§lTotem §r" + "§l" + count, px, py, color);

        // Pop flash
        long elapsed = System.currentTimeMillis() - popTime;
        if (elapsed < 1500) {
            float alpha = 1f - (elapsed / 1500f);
            int a = (int)(alpha * 200);
            int flashColor = (a << 24) | 0xFF4400;
            RenderUtil.drawText(event.getContext(), "§cPOP!", px + 90, py, flashColor);
        }
    }
}
