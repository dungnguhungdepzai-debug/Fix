package dev.kingcrystal.modules.hud;

import dev.kingcrystal.event.EventHandler;
import dev.kingcrystal.event.events.RenderHudEvent;
import dev.kingcrystal.modules.Module;
import dev.kingcrystal.modules.settings.BooleanSetting;
import dev.kingcrystal.modules.settings.SliderSetting;
import dev.kingcrystal.util.RenderUtil;
import net.minecraft.item.ItemStack;

public class InventoryHudModule extends Module {

    private final SliderSetting x = addSetting(new SliderSetting("X", "HUD X", 10, 0, 1920, 1));
    private final SliderSetting y = addSetting(new SliderSetting("Y", "HUD Y", 400, 0, 1080, 1));
    private final BooleanSetting showHotbar = addSetting(new BooleanSetting("Hotbar Only", "Show only hotbar", false));

    public InventoryHudModule() {
        super("Inventory HUD", "Displays inventory contents", Category.HUD);
    }

    @EventHandler
    public void onRenderHud(RenderHudEvent event) {
        if (mc.player == null) return;

        int px = (int) x.getValue();
        int py = (int) y.getValue();
        boolean hotbarOnly = showHotbar.getValue();

        int rows = hotbarOnly ? 1 : 4;
        int cols = 9;
        int slotSize = 18;
        int panelW = cols * slotSize + 4;
        int panelH = rows * slotSize + 4;

        RenderUtil.drawRoundedRect(event.getContext(), px - 2, py - 2, panelW, panelH, 3, 0xCC060612);
        RenderUtil.drawGradientBorder(event.getContext(), px - 2, py - 2, panelW, panelH, 3, 1, 0x558800FF, 0x550088FF);

        int startSlot = hotbarOnly ? 36 : 9;
        int endSlot = 45;

        int slot = startSlot;
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                if (slot >= endSlot) break;
                ItemStack stack = mc.player.getInventory().getStack(slot);
                int sx = px + col * slotSize;
                int sy = py + row * slotSize;
                event.getContext().drawItem(stack, sx, sy);
                event.getContext().drawItemInSlot(mc.textRenderer, stack, sx, sy, null);
                slot++;
            }
        }
    }
}
