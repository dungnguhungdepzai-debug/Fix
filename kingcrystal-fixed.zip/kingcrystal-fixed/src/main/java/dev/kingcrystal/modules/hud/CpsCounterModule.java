package dev.kingcrystal.modules.hud;

import dev.kingcrystal.event.EventHandler;
import dev.kingcrystal.event.events.RenderHudEvent;
import dev.kingcrystal.modules.Module;
import dev.kingcrystal.modules.settings.SliderSetting;
import dev.kingcrystal.util.RenderUtil;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Deque;

public class CpsCounterModule extends Module {

    private final SliderSetting x = addSetting(new SliderSetting("X", "HUD X", 10, 0, 1920, 1));
    private final SliderSetting y = addSetting(new SliderSetting("Y", "HUD Y", 70, 0, 1080, 1));

    private final Deque<Long> leftClicks = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();
    private boolean wasLeftDown = false;
    private boolean wasRightDown = false;

    public CpsCounterModule() {
        super("CPS Counter", "Shows clicks per second for both mouse buttons", Category.HUD);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.getWindow() == null) return;
        long handle = client.getWindow().getHandle();
        long now = System.currentTimeMillis();

        boolean leftDown = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean rightDown = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;

        if (leftDown && !wasLeftDown) leftClicks.addLast(now);
        if (rightDown && !wasRightDown) rightClicks.addLast(now);

        wasLeftDown = leftDown;
        wasRightDown = rightDown;

        pruneOld(leftClicks, now);
        pruneOld(rightClicks, now);
    }

    private void pruneOld(Deque<Long> deque, long now) {
        while (!deque.isEmpty() && now - deque.peekFirst() > 1000) deque.pollFirst();
    }

    @EventHandler
    public void onRenderHud(RenderHudEvent event) {
        int px = (int) x.getValue();
        int py = (int) y.getValue();
        long now = System.currentTimeMillis();
        pruneOld(leftClicks, now);
        pruneOld(rightClicks, now);

        RenderUtil.drawRoundedRect(event.getContext(), px - 2, py - 2, 140, 20, 4, 0xCC0A0A14);
        RenderUtil.drawText(event.getContext(),
                "§5§lCPS §r§bL:" + leftClicks.size() + " §dR:" + rightClicks.size(),
                px, py, 0xFFFFFFFF);
    }
}
