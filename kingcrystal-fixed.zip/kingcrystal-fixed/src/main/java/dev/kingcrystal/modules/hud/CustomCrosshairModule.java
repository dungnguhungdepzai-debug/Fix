package dev.kingcrystal.modules.hud;

import dev.kingcrystal.event.EventHandler;
import dev.kingcrystal.event.events.RenderHudEvent;
import dev.kingcrystal.modules.Module;
import dev.kingcrystal.modules.settings.ColorSetting;
import dev.kingcrystal.modules.settings.ModeSetting;
import dev.kingcrystal.modules.settings.SliderSetting;
import dev.kingcrystal.util.RenderUtil;

public class CustomCrosshairModule extends Module {

    private final ModeSetting style = addSetting(new ModeSetting("Style", "Crosshair style", "Cross", "Cross", "Dot", "Circle", "Plus"));
    private final SliderSetting size = addSetting(new SliderSetting("Size", "Crosshair size", 6, 2, 20, 1));
    private final SliderSetting gap = addSetting(new SliderSetting("Gap", "Center gap", 2, 0, 10, 1));
    private final SliderSetting thickness = addSetting(new SliderSetting("Thickness", "Line thickness", 1, 1, 4, 1));
    private final ColorSetting color = addSetting(new ColorSetting("Color", "Crosshair color", 0xFFFFFFFF));

    public CustomCrosshairModule() {
        super("Custom Crosshair", "Replaces the default crosshair", Category.VISUAL);
    }

    @EventHandler
    public void onRenderHud(RenderHudEvent event) {
        if (mc.options.getPerspective().isFirstPerson()) {
            int sw = mc.getWindow().getScaledWidth();
            int sh = mc.getWindow().getScaledHeight();
            int cx = sw / 2;
            int cy = sh / 2;
            int s = (int) size.getValue();
            int g = (int) gap.getValue();
            int t = (int) thickness.getValue();
            int col = color.getValue();

            switch (style.getValue()) {
                case "Cross" -> {
                    // Horizontal
                    RenderUtil.drawRect(event.getContext(), cx - s - g, cy - t / 2, s, t, col);
                    RenderUtil.drawRect(event.getContext(), cx + g + 1, cy - t / 2, s, t, col);
                    // Vertical
                    RenderUtil.drawRect(event.getContext(), cx - t / 2, cy - s - g, t, s, col);
                    RenderUtil.drawRect(event.getContext(), cx - t / 2, cy + g + 1, t, s, col);
                }
                case "Dot" -> RenderUtil.drawCircle(event.getContext(), cx, cy, s / 2, col);
                case "Circle" -> RenderUtil.drawCircleOutline(event.getContext(), cx, cy, s, t, col);
                case "Plus" -> {
                    RenderUtil.drawRect(event.getContext(), cx - s, cy - t / 2, s * 2 + 1, t, col);
                    RenderUtil.drawRect(event.getContext(), cx - t / 2, cy - s, t, s * 2 + 1, col);
                }
            }
        }
    }
}
