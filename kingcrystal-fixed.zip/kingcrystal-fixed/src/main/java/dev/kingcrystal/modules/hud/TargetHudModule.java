package dev.kingcrystal.modules.hud;

import dev.kingcrystal.event.EventHandler;
import dev.kingcrystal.event.events.RenderHudEvent;
import dev.kingcrystal.modules.Module;
import dev.kingcrystal.modules.settings.SliderSetting;
import dev.kingcrystal.util.RenderUtil;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;

import java.util.Comparator;
import java.util.Optional;

public class TargetHudModule extends Module {

    private final SliderSetting x = addSetting(new SliderSetting("X", "HUD X", 10, 0, 1920, 1));
    private final SliderSetting y = addSetting(new SliderSetting("Y", "HUD Y", 200, 0, 1080, 1));
    private final SliderSetting range = addSetting(new SliderSetting("Range", "Target range", 20, 1, 100, 0.5));

    public TargetHudModule() {
        super("Target HUD", "Shows information about the nearest player", Category.HUD);
    }

    @EventHandler
    public void onRenderHud(RenderHudEvent event) {
        if (mc.world == null || mc.player == null) return;

        Optional<PlayerEntity> target = mc.world.getEntitiesByClass(PlayerEntity.class,
                mc.player.getBoundingBox().expand(range.getValue()), e -> e != mc.player)
                .stream()
                .min(Comparator.comparingDouble(e -> e.distanceTo(mc.player)));

        if (target.isEmpty()) return;
        PlayerEntity t = target.get();

        int px = (int) x.getValue();
        int py = (int) y.getValue();
        int w = 180, h = 60;

        RenderUtil.drawRoundedRect(event.getContext(), px, py, w, h, 6, 0xDD060612);
        RenderUtil.drawGradientBorder(event.getContext(), px, py, w, h, 6, 1, 0xFFFF4466, 0xFFFF8800);

        // Name
        String name = t.getName().getString();
        RenderUtil.drawText(event.getContext(), "§c§l" + name, px + 6, py + 5, 0xFFFF6688);

        // Health bar
        float maxHp = (float) t.getAttributeValue(EntityAttributes.MAX_HEALTH);
        float hp = t.getHealth();
        float absorp = t.getAbsorptionAmount();
        float hpPercent = hp / maxHp;
        float absPercent = Math.min(absorp / maxHp, 1f);

        int barX = px + 6, barY = py + 20, barW = w - 12, barH = 6;
        RenderUtil.drawRoundedRect(event.getContext(), barX, barY, barW, barH, 3, 0xFF222222);
        RenderUtil.drawRoundedRect(event.getContext(), barX, barY, (int)(barW * hpPercent), barH, 3, hpColor(hpPercent));
        if (absPercent > 0)
            RenderUtil.drawRoundedRect(event.getContext(), barX, barY, (int)(barW * absPercent), barH, 3, 0xAAFFD700);

        RenderUtil.drawText(event.getContext(), String.format("§7HP: §f%.1f §7/ §f%.1f", hp, maxHp), px + 6, py + 30, 0xFFCCCCCC);
        RenderUtil.drawText(event.getContext(), String.format("§7Dist: §b%.1f", t.distanceTo(mc.player)), px + 6, py + 42, 0xFFCCCCCC);
    }

    private int hpColor(float percent) {
        if (percent > 0.6f) return 0xFF44FF44;
        if (percent > 0.3f) return 0xFFFFAA00;
        return 0xFFFF3333;
    }
}
