package dev.kingcrystal.modules.hud;

import dev.kingcrystal.KingCrystalClient;
import dev.kingcrystal.event.EventHandler;
import dev.kingcrystal.event.events.RenderHudEvent;
import dev.kingcrystal.modules.Module;
import dev.kingcrystal.modules.settings.SliderSetting;
import dev.kingcrystal.util.RenderUtil;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class KeybindHudModule extends Module {

    private final SliderSetting x = addSetting(new SliderSetting("X", "HUD X", 10, 0, 1920, 1));
    private final SliderSetting y = addSetting(new SliderSetting("Y", "HUD Y", 450, 0, 1080, 1));

    // Track pressed states for debounce
    private final java.util.Map<Integer, Boolean> wasPressed = new java.util.HashMap<>();

    public KeybindHudModule() {
        super("Keybind HUD", "Shows module keybinds and allows toggling", Category.HUD);
    }

    @Override
    public void onTick(net.minecraft.client.MinecraftClient client) {
        if (client.getWindow() == null) return;
        long handle = client.getWindow().getHandle();

        List<Module> modules = KingCrystalClient.getInstance().getModuleManager().getModules();
        for (Module mod : modules) {
            int key = mod.getKeybind();
            if (key == -1) continue;

            boolean isDown = GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS;
            boolean was = wasPressed.getOrDefault(key, false);
            if (isDown && !was) mod.toggle();
            wasPressed.put(key, isDown);
        }
    }

    @EventHandler
    public void onRenderHud(RenderHudEvent event) {
        List<Module> modules = KingCrystalClient.getInstance().getModuleManager().getModules();

        int px = (int) x.getValue();
        int py = (int) y.getValue();
        int lineY = py;

        for (Module mod : modules) {
            if (mod.getKeybind() == -1) continue;
            String keyName = GLFW.glfwGetKeyName(mod.getKeybind(), 0);
            if (keyName == null) keyName = "Key" + mod.getKeybind();
            String line = "§7[§b" + keyName.toUpperCase() + "§7] §f" + mod.getName();
            RenderUtil.drawText(event.getContext(), line, px, lineY, 0xFFFFFFFF);
            lineY += 11;
        }
    }
}
