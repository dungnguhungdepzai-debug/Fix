package dev.kingcrystal.modules.hud;

import dev.kingcrystal.event.EventHandler;
import dev.kingcrystal.event.events.RenderHudEvent;
import dev.kingcrystal.modules.Module;
import dev.kingcrystal.modules.settings.BooleanSetting;
import dev.kingcrystal.modules.settings.SliderSetting;
import dev.kingcrystal.util.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.decoration.EndCrystalEntity;

public class CrystalCounterModule extends Module {

    private final SliderSetting x = addSetting(new SliderSetting("X", "HUD X position", 10, 0, 1920, 1));
    private final SliderSetting y = addSetting(new SliderSetting("Y", "HUD Y position", 10, 0, 1080, 1));
    private final BooleanSetting background = addSetting(new BooleanSetting("Background", "Draw background", true));

    public CrystalCounterModule() {
        super("Crystal Counter", "Shows number of End Crystals nearby", Category.HUD);
    }

    @EventHandler
    public void onRenderHud(RenderHudEvent event) {
        if (mc.world == null) return;

        long count = mc.world.getEntities().stream()
                .filter(e -> e instanceof EndCrystalEntity)
                .count();

        int px = (int) x.getValue();
        int py = (int) y.getValue();

        if (background.getValue())
            RenderUtil.drawRoundedRect(event.getContext(), px - 2, py - 2, 130, 20, 4, 0xCC0A0A14);

        RenderUtil.drawText(event.getContext(), "§5§lCrystals §r§b" + count, px, py, 0xFFCCAAFF);
    }
}
