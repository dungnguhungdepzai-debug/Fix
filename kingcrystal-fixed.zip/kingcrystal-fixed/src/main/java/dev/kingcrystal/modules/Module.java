package dev.kingcrystal.modules;

import dev.kingcrystal.KingCrystalClient;
import dev.kingcrystal.modules.settings.Setting;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {

    public enum Category {
        HUD("HUD"),
        COMBAT("Combat"),
        VISUAL("Visual"),
        MISC("Misc");

        private final String displayName;
        Category(String displayName) { this.displayName = displayName; }
        public String getDisplayName() { return displayName; }
    }

    protected final MinecraftClient mc = MinecraftClient.getInstance();
    private final String name;
    private final String description;
    private final Category category;
    private final List<Setting<?>> settings = new ArrayList<>();
    private boolean enabled;
    private int keybind = -1;

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.enabled = false;
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(MinecraftClient client) {}

    public void toggle() {
        enabled = !enabled;
        if (enabled) {
            KingCrystalClient.getInstance().getEventBus().register(this);
            onEnable();
        } else {
            KingCrystalClient.getInstance().getEventBus().unregister(this);
            onDisable();
        }
        KingCrystalClient.getInstance().getConfigManager().save(
                KingCrystalClient.getInstance().getModuleManager()
        );
    }

    public void setEnabled(boolean enabled) {
        if (this.enabled != enabled) toggle();
    }

    protected <T extends Setting<?>> T addSetting(T setting) {
        settings.add(setting);
        return setting;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public List<Setting<?>> getSettings() { return settings; }
    public boolean isEnabled() { return enabled; }
    public int getKeybind() { return keybind; }
    public void setKeybind(int key) { this.keybind = key; }
}
