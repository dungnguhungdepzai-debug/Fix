package dev.kingcrystal.modules;

import dev.kingcrystal.event.EventBus;
import dev.kingcrystal.modules.hud.*;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.*;
import java.util.stream.Collectors;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();
    private final EventBus eventBus;

    public ModuleManager(EventBus eventBus) {
        this.eventBus = eventBus;
        registerModules();
    }

    private void registerModules() {
        // HUD Modules
        register(new CrystalCounterModule());
        register(new CrystalHudModule());
        register(new TargetHudModule());
        register(new TotemCounterModule());
        register(new ArmorHudModule());
        register(new InventoryHudModule());
        register(new CpsCounterModule());
        register(new FpsDisplayModule());
        register(new PingDisplayModule());
        register(new KeybindHudModule());
        register(new CustomCrosshairModule());
        register(new CrystalVisualsModule());
        register(new DamageIndicatorModule());
    }

    private void register(Module module) {
        modules.add(module);
    }

    public void onTick(MinecraftClient client) {
        // Handle keybind toggles
        for (Module module : modules) {
            if (module.getKeybind() == -1) continue;
            if (GLFW.glfwGetKey(client.getWindow().getHandle(), module.getKeybind()) == GLFW.GLFW_PRESS) {
                // debounce handled by KeybindHudModule
            }
        }
        // Tick enabled modules
        for (Module module : modules) {
            if (module.isEnabled()) {
                module.onTick(client);
            }
        }
    }

    public List<Module> getModules() { return Collections.unmodifiableList(modules); }

    public List<Module> getModulesByCategory(Module.Category category) {
        return modules.stream()
                .filter(m -> m.getCategory() == category)
                .collect(Collectors.toList());
    }

    public Optional<Module> getModuleByName(String name) {
        return modules.stream().filter(m -> m.getName().equalsIgnoreCase(name)).findFirst();
    }

    public List<Module> search(String query) {
        if (query == null || query.isBlank()) return modules;
        String q = query.toLowerCase();
        return modules.stream()
                .filter(m -> m.getName().toLowerCase().contains(q)
                          || m.getDescription().toLowerCase().contains(q))
                .collect(Collectors.toList());
    }
}
