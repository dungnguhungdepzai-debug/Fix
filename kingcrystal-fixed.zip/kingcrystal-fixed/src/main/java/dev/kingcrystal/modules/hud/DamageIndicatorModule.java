package dev.kingcrystal.modules.hud;

import dev.kingcrystal.event.EventHandler;
import dev.kingcrystal.event.events.RenderHudEvent;
import dev.kingcrystal.event.events.TickEvent;
import dev.kingcrystal.modules.Module;
import dev.kingcrystal.modules.settings.SliderSetting;
import dev.kingcrystal.util.RenderUtil;
import net.minecraft.entity.LivingEntity;

import java.util.*;

public class DamageIndicatorModule extends Module {

    private final SliderSetting duration = addSetting(new SliderSetting("Duration", "Display duration (ms)", 1500, 500, 5000, 100));
    private final SliderSetting range = addSetting(new SliderSetting("Range", "Detection range", 20, 1, 50, 1));

    private final Map<Integer, Float> lastHealthMap = new HashMap<>();
    private final List<DamageIndicator> indicators = new ArrayList<>();

    public DamageIndicatorModule() {
        super("Damage Indicator", "Shows damage dealt to entities", Category.HUD);
    }

    @EventHandler
    public void onTick(TickEvent event) {
        if (mc.world == null || mc.player == null) return;

        mc.world.getEntitiesByClass(LivingEntity.class,
                mc.player.getBoundingBox().expand(range.getValue()), e -> e != mc.player)
                .forEach(entity -> {
                    Float lastHp = lastHealthMap.get(entity.getId());
                    float currentHp = entity.getHealth();

                    if (lastHp != null && lastHp > currentHp) {
                        float damage = lastHp - currentHp;
                        indicators.add(new DamageIndicator(
                                entity.getX(), entity.getY() + entity.getHeight(),
                                entity.getZ(), damage, System.currentTimeMillis()
                        ));
                    }
                    lastHealthMap.put(entity.getId(), currentHp);
                });

        long now = System.currentTimeMillis();
        long dur = (long) duration.getValue();
        indicators.removeIf(d -> now - d.createTime > dur);
    }

    @EventHandler
    public void onRenderHud(RenderHudEvent event) {
        if (mc.player == null) return;
        long now = System.currentTimeMillis();
        long dur = (long) duration.getValue();

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int cx = sw / 2;
        int cy = sh / 2;

        for (DamageIndicator ind : new ArrayList<>(indicators)) {
            long elapsed = now - ind.createTime;
            float progress = (float) elapsed / dur;
            int alpha = (int)((1f - progress) * 255);
            if (alpha <= 0) continue;

            float rise = progress * 30f;

            // Simple world-to-screen approximation relative to player
            double relX = ind.worldX - mc.player.getX();
            double relZ = ind.worldZ - mc.player.getZ();

            // Project using player yaw
            float yaw = (float) Math.toRadians(mc.player.getYaw());
            double screenX = relX * Math.cos(yaw) - relZ * Math.sin(-yaw);
            double screenZ = relX * Math.sin(-yaw) + relZ * Math.cos(yaw);

            // Only draw if roughly in front
            if (screenZ > 0.5) {
                int drawX = cx + (int)(screenX / screenZ * 80);
                int drawY = cy - (int)(30 / screenZ) - (int)rise;

                int color = (alpha << 24) | 0xFF3333;
                RenderUtil.drawText(event.getContext(),
                        String.format("\u00a7c-%.1f", ind.damage), drawX, drawY, color);
            }
        }
    }

    private record DamageIndicator(double worldX, double worldY, double worldZ, float damage, long createTime) {}
}
