package dev.kingcrystal.modules.hud;

import dev.kingcrystal.event.EventHandler;
import dev.kingcrystal.event.events.RenderHudEvent;
import dev.kingcrystal.modules.Module;
import dev.kingcrystal.modules.settings.BooleanSetting;
import dev.kingcrystal.modules.settings.SliderSetting;
import dev.kingcrystal.util.RenderUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class CrystalHudModule extends Module {

    private final SliderSetting x = addSetting(new SliderSetting("X", "HUD X", 10, 0, 1920, 1));
    private final SliderSetting y = addSetting(new SliderSetting("Y", "HUD Y", 100, 0, 1080, 1));
    private final BooleanSetting showCrystals = addSetting(new BooleanSetting("Show Crystals", "Show crystal count", true));
    private final BooleanSetting showObsidian = addSetting(new BooleanSetting("Show Obsidian", "Show obsidian count", true));
    private final BooleanSetting showAnchors = addSetting(new BooleanSetting("Show Totems", "Show totem count", true));

    public CrystalHudModule() {
        super("Crystal HUD", "Crystal PvP information HUD", Category.HUD);
    }

    @EventHandler
    public void onRenderHud(RenderHudEvent event) {
        if (mc.world == null || mc.player == null) return;

        int px = (int) x.getValue();
        int py = (int) y.getValue();
        int width = 160, height = 80;

        RenderUtil.drawRoundedRect(event.getContext(), px - 4, py - 4, width, height, 6, 0xDD060612);
        RenderUtil.drawGradientBorder(event.getContext(), px - 4, py - 4, width, height, 6, 1, 0xFF8800FF, 0xFF0088FF);

        // Header
        RenderUtil.drawTextCentered(event.getContext(), "§5§l⬡ Crystal PvP", px + width / 2 - 4, py, 0xFFCCAAFF);
        RenderUtil.drawLine(event.getContext(), px - 4, py + 11, px + width - 4, py + 11, 0x558800FF);

        int lineY = py + 15;

        if (showCrystals.getValue()) {
            long crystals = mc.world.getEntities().stream()
                    .filter(e -> e instanceof EndCrystalEntity).count();
            RenderUtil.drawText(event.getContext(), "§7Crystals: §b" + crystals, px, lineY, 0xFFFFFFFF);
            lineY += 12;
        }

        if (showObsidian.getValue()) {
            int obsidian = countItem(mc.player, net.minecraft.item.Items.OBSIDIAN);
            RenderUtil.drawText(event.getContext(), "§7Obsidian: §d" + obsidian, px, lineY, 0xFFFFFFFF);
            lineY += 12;
        }

        if (showAnchors.getValue()) {
            int totems = countItem(mc.player, net.minecraft.item.Items.TOTEM_OF_UNDYING);
            RenderUtil.drawText(event.getContext(), "§7Totems: §a" + totems, px, lineY, 0xFFFFFFFF);
        }
    }

    private int countItem(PlayerEntity player, net.minecraft.item.Item item) {
        int count = 0;
        for (int i = 0; i < player.getInventory().size(); i++) {
            var stack = player.getInventory().getStack(i);
            if (stack.getItem() == item) count += stack.getCount();
        }
        return count;
    }
}
