package dev.kingcrystal.event;

public abstract class Event {
    public String getName() {
        return getClass().getSimpleName();
    }
}
