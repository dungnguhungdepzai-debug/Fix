package dev.kingcrystal.event;

public interface Cancellable {
    boolean isCancelled();
    void setCancelled(boolean cancelled);
}
