package dev.kingcrystal.event.events;

import dev.kingcrystal.event.Event;
import net.minecraft.client.MinecraftClient;

public class TickEvent extends Event {
    private final MinecraftClient client;

    public TickEvent(MinecraftClient client) {
        this.client = client;
    }

    public MinecraftClient getClient() { return client; }
}
