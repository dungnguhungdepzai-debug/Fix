package dev.kingcrystal.event;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class EventBus {

    private final Map<Class<?>, List<ListenerEntry>> listeners = new ConcurrentHashMap<>();

    public void register(Object listener) {
        for (Method method : listener.getClass().getDeclaredMethods()) {
            if (!method.isAnnotationPresent(EventHandler.class)) continue;
            if (method.getParameterCount() != 1) continue;

            Class<?> eventType = method.getParameterTypes()[0];
            method.setAccessible(true);

            listeners.computeIfAbsent(eventType, k -> new CopyOnWriteArrayList<>())
                     .add(new ListenerEntry(listener, method, method.getAnnotation(EventHandler.class).priority()));

            listeners.get(eventType).sort(Comparator.comparingInt(e -> -e.priority));
        }
    }

    public void unregister(Object listener) {
        for (List<ListenerEntry> entries : listeners.values()) {
            entries.removeIf(entry -> entry.listener == listener);
        }
    }

    public void post(Event event) {
        List<ListenerEntry> entries = listeners.get(event.getClass());
        if (entries == null) return;

        for (ListenerEntry entry : entries) {
            if (event instanceof Cancellable cancellable && cancellable.isCancelled()) break;
            try {
                entry.method.invoke(entry.listener, event);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static class ListenerEntry {
        final Object listener;
        final Method method;
        final int priority;

        ListenerEntry(Object listener, Method method, int priority) {
            this.listener = listener;
            this.method = method;
            this.priority = priority;
        }
    }
}
