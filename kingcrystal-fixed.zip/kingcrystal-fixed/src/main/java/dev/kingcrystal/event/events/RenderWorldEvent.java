package dev.kingcrystal.event.events;

import dev.kingcrystal.event.Event;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;

public class RenderWorldEvent extends Event {
    private final MatrixStack matrixStack;
    private final Camera camera;
    private final float tickDelta;

    public RenderWorldEvent(MatrixStack matrixStack, Camera camera, float tickDelta) {
        this.matrixStack = matrixStack;
        this.camera = camera;
        this.tickDelta = tickDelta;
    }

    public MatrixStack getMatrixStack() { return matrixStack; }
    public Camera getCamera() { return camera; }
    public float getTickDelta() { return tickDelta; }
}
