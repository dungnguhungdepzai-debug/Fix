package dev.kingcrystal.mixin;

import dev.kingcrystal.KingCrystalClient;
import dev.kingcrystal.event.events.RenderHudEvent;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (KingCrystalClient.getInstance() == null) return;
        KingCrystalClient.getInstance().getEventBus().post(
                new RenderHudEvent(context, tickCounter.getTickDelta(true))
        );
    }
}
