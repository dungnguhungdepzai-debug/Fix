package dev.kingcrystal;

import dev.kingcrystal.config.ConfigManager;
import dev.kingcrystal.event.EventBus;
import dev.kingcrystal.gui.ClickGUI;
import dev.kingcrystal.modules.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class KingCrystalClient implements ClientModInitializer {

    public static final String MOD_ID = "kingcrystal";
    public static final String MOD_NAME = "KingCrystal";
    public static final String MOD_VERSION = "1.0.0";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_NAME);

    private static KingCrystalClient INSTANCE;

    private ModuleManager moduleManager;
    private ConfigManager configManager;
    private EventBus eventBus;
    private ClickGUI clickGUI;
    private KeyBinding guiKeyBinding;

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        LOGGER.info("KingCrystal Client v{} initializing...", MOD_VERSION);

        eventBus = new EventBus();
        configManager = new ConfigManager();
        moduleManager = new ModuleManager(eventBus);
        clickGUI = new ClickGUI(moduleManager);

        configManager.load(moduleManager);

        guiKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kingcrystal.gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.kingcrystal"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guiKeyBinding.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(clickGUI);
                }
            }
            eventBus.post(new dev.kingcrystal.event.events.TickEvent(client));
            moduleManager.onTick(client);
        });

        LOGGER.info("KingCrystal Client initialized successfully.");
    }

    public static KingCrystalClient getInstance() { return INSTANCE; }
    public ModuleManager getModuleManager() { return moduleManager; }
    public ConfigManager getConfigManager() { return configManager; }
    public EventBus getEventBus() { return eventBus; }
    public ClickGUI getClickGUI() { return clickGUI; }
}
