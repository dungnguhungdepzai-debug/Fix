package dev.kingcrystal.config;

import com.google.gson.*;
import dev.kingcrystal.KingCrystalClient;
import dev.kingcrystal.modules.Module;
import dev.kingcrystal.modules.ModuleManager;
import dev.kingcrystal.modules.settings.*;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.*;

public class ConfigManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path configDir;
    private final Path configFile;

    public ConfigManager() {
        configDir = FabricLoader.getInstance().getConfigDir().resolve("kingcrystal");
        configFile = configDir.resolve("modules.json");
        try {
            Files.createDirectories(configDir);
        } catch (IOException e) {
            KingCrystalClient.LOGGER.error("Failed to create config directory", e);
        }
    }

    public void save(ModuleManager manager) {
        JsonObject root = new JsonObject();
        for (Module module : manager.getModules()) {
            JsonObject modObj = new JsonObject();
            modObj.addProperty("enabled", module.isEnabled());
            modObj.addProperty("keybind", module.getKeybind());

            JsonObject settingsObj = new JsonObject();
            for (Setting<?> setting : module.getSettings()) {
                serializeSetting(settingsObj, setting);
            }
            modObj.add("settings", settingsObj);
            root.add(module.getName(), modObj);
        }

        try (Writer writer = Files.newBufferedWriter(configFile)) {
            GSON.toJson(root, writer);
        } catch (IOException e) {
            KingCrystalClient.LOGGER.error("Failed to save config", e);
        }
    }

    public void load(ModuleManager manager) {
        if (!Files.exists(configFile)) return;

        try (Reader reader = Files.newBufferedReader(configFile)) {
            JsonObject root = GSON.fromJson(reader, JsonObject.class);
            if (root == null) return;

            for (Module module : manager.getModules()) {
                if (!root.has(module.getName())) continue;
                JsonObject modObj = root.getAsJsonObject(module.getName());

                if (modObj.has("keybind"))
                    module.setKeybind(modObj.get("keybind").getAsInt());

                boolean shouldEnable = modObj.has("enabled") && modObj.get("enabled").getAsBoolean();
                if (shouldEnable != module.isEnabled()) module.toggle();

                if (modObj.has("settings")) {
                    JsonObject settingsObj = modObj.getAsJsonObject("settings");
                    for (Setting<?> setting : module.getSettings()) {
                        deserializeSetting(settingsObj, setting);
                    }
                }
            }
        } catch (Exception e) {
            KingCrystalClient.LOGGER.error("Failed to load config", e);
        }
    }

    @SuppressWarnings("unchecked")
    private void serializeSetting(JsonObject obj, Setting<?> setting) {
        if (setting instanceof BooleanSetting s)
            obj.addProperty(s.getName(), s.getValue());
        else if (setting instanceof SliderSetting s)
            obj.addProperty(s.getName(), s.getValue());
        else if (setting instanceof ModeSetting s)
            obj.addProperty(s.getName(), s.getValue());
        else if (setting instanceof ColorSetting s)
            obj.addProperty(s.getName(), s.getValue());
    }

    @SuppressWarnings("unchecked")
    private void deserializeSetting(JsonObject obj, Setting<?> setting) {
        if (!obj.has(setting.getName())) return;
        JsonElement el = obj.get(setting.getName());
        try {
            if (setting instanceof BooleanSetting s)
                s.setValue(el.getAsBoolean());
            else if (setting instanceof SliderSetting s)
                s.setValue(el.getAsDouble());
            else if (setting instanceof ModeSetting s)
                s.setValue(el.getAsString());
            else if (setting instanceof ColorSetting s)
                s.setValue(el.getAsInt());
        } catch (Exception e) {
            KingCrystalClient.LOGGER.warn("Failed to deserialize setting: {}", setting.getName());
        }
    }
}
